# Where future features belong

Use `launch.py` as the entry point and `preflight.py` for prerequisites. Feature additions should extend these, rather than introducing unrelated top-level scripts.

| Work | Location |
| --- | --- |
| Camera input, detection, tracking, scene interpretation | `apps/vision/` |
| Speech recognition and reusable text-to-speech processing | `apps/voice/` |
| Physical robot speaker, cameras, movement SDK connections | `apps/hardware/` |
| MuJoCo gestures and visual demonstrations | `apps/simulation/` |
| Reusable simulation movement definitions | `motions/simulation/` |
| Verified onboard action mappings and hardware motion metadata | `motions/hardware/` |
| Downloaded vision and speech model weights | `models/vision/`, `models/speech/` |
| Recorded/generated audio clips for playback | `assets/audio/` |
| Automated regression tests | `tests/` |
| Setup, hardware instructions, feature explanations | `docs/` |
| Earlier implementations and downloads | `archive/` |

The movement and audio directories are reserved/documented locations, not active movement loaders. Existing inline gesture definitions remain in the simulator until a movement-loader feature is deliberately implemented.

## Movement conventions

Use descriptive names such as `greeting_wave` or `welcome_sequence`, rather than `new`, `final`, or numbered backups. For movement definitions record the robot/model variant, units, duration, required joints, and whether the motion is only a simulation. Hardware definitions must identify the actual onboard action/service and verified firmware compatibility. Simulation joint angles must not silently become hardware commands. Keep SDK-owned files in the third-party repository unchanged.

## Speech input versus speech output

The downloaded Vosk package and English model convert microphone audio to text. They do not synthesize speech. The voice simulator now speaks preset replies through the Mac speakers using `apps/voice/local_speech.py`. It also supports a standalone `launch.py speak --text "..."` command.

The installed Unitree G1 SDK separately exposes `AudioClient.TtsMaker(text, speaker_id)` for text-to-speech, `GetVolume()` for a read-only audio-service check, and `PlayStream()` for audio playback. Physical output requires connectivity and an available compatible robot audio service. These have not been tested on this robot.

A future speaker integration belongs in `apps/hardware/robot_speech.py`; any reusable local speech-generation code belongs in `apps/voice/`. Add an audio-service preflight using `GetVolume()` before speech output, rather than requiring arm-action discovery for an audio-only app. Text-to-speech speaker IDs/languages and playback formats must be checked against the installed robot's SDK/firmware. Keep the initial audio test independent of movement and leave volume unchanged unless explicitly requested.

Source: https://github.com/unitreerobotics/unitree_sdk2_python/blob/master/unitree_sdk2py/g1/audio/g1_audio_client.py
