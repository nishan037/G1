"""Local speech output for the simulator, using macOS's installed voices."""
import argparse
from pathlib import Path
import queue
import shutil
import subprocess
import threading
import time


def speech_command(text):
    engine = shutil.which('say')
    if not engine:
        raise RuntimeError('macOS say is unavailable; local speech output requires macOS.')
    text = str(text).strip()
    if not text or len(text) > 2000:
        raise ValueError('Speech text must contain 1–2000 characters.')
    # Text is an argument, never shell code. -- also protects leading hyphens.
    return [engine, '-r', '165', '--', text]


class LocalSpeaker:
    def __init__(self):
        speech_command('ready')
        self.caption = ''
        self._queue = queue.Queue()
        self._lock = threading.Lock()
        self._process = None
        self._pending = False
        self._generation = 0
        self._cooldown = 0.
        self._closed = False
        threading.Thread(target=self._worker, daemon=True).start()

    def is_speaking(self):
        with self._lock:
            return self._pending or time.monotonic() < self._cooldown

    def speak(self, text):
        command = speech_command(text)
        with self._lock:
            if self._closed or self._pending:
                return False
            self.caption = text
            self._pending = True
            self._queue.put((self._generation, command))
        print(f'G1 says: {text}', flush=True)
        return True

    def _worker(self):
        while True:
            item = self._queue.get()
            if item is None:
                return
            generation, command = item
            process = None
            try:
                with self._lock:
                    if self._closed or generation != self._generation:
                        continue
                    process = subprocess.Popen(command)
                    self._process = process
                code = process.wait(timeout=60)
                if code != 0:
                    print(f'Speech output exited with code {code}.', flush=True)
            except Exception as exc:
                if process and process.poll() is None:
                    process.terminate()
                print(f'Speech output unavailable: {exc}', flush=True)
            finally:
                with self._lock:
                    if generation == self._generation:
                        self._process = None
                        self._pending = False
                        self._cooldown = time.monotonic() + .6

    def stop(self):
        with self._lock:
            self._generation += 1
            self._pending = False
            self._cooldown = time.monotonic() + .6
            if self._process and self._process.poll() is None:
                self._process.terminate()
            self._process = None

    def close(self):
        self.stop()
        with self._lock:
            self._closed = True
        self._queue.put(None)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--text', default='Hello! I am G one. Welcome to the simulation.')
    args = parser.parse_args()
    return subprocess.call(speech_command(args.text))


if __name__ == '__main__':
    raise SystemExit(main())
