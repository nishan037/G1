"""Voice-only conversation with Ollama Cloud. No physical robot commands."""
import argparse
from pathlib import Path
import json
import queue
import sys
import threading
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'apps/ai'))
sys.path.insert(0, str(ROOT / 'apps/voice'))
from ollama_cloud_client import OllamaCloud, CloudError
from local_speech import LocalSpeaker


def control(text):
    value = text.lower().strip().rstrip('.!?')
    if value in ('/quit', 'quit', 'exit', 'goodbye g one'):
        return 'quit'
    if value in ('/stop', 'stop', 'stop speaking'):
        return 'stop'
    if value in ('/reset', 'reset conversation', 'start a new conversation'):
        return 'reset'
    if value in ('/help', 'help'):
        return 'help'
    return None


def microphone_worker(inputs, done, listening, speaker, device):
    try:
        import sounddevice as sd
        from vosk import Model, KaldiRecognizer, SetLogLevel
        SetLogLevel(-1)
        model = Model(str(ROOT / 'models/speech/vosk-model-small-en-us-0.15'))
        info = sd.query_devices(device, 'input')
        rate = int(info['default_samplerate'])
        # General transcription: no fixed command grammar.
        recognizer = KaldiRecognizer(model, rate)
        audio = queue.Queue(maxsize=20)
        def callback(data, frames, timing, status):
            if listening.is_set() and not (speaker and speaker.is_speaking()):
                try:
                    audio.put_nowait(bytes(data))
                except queue.Full:
                    pass
        with sd.RawInputStream(device=device, samplerate=rate, channels=1, dtype='int16',
                               blocksize=rate // 5, callback=callback):
            print(f'VOICE READY: {info["name"]}. Ask a question, then pause.', flush=True)
            while not done.is_set():
                if not listening.is_set() or (speaker and speaker.is_speaking()):
                    recognizer.Reset()
                    while not audio.empty():
                        try: audio.get_nowait()
                        except queue.Empty: break
                    done.wait(.05)
                    continue
                try:
                    chunk = audio.get(timeout=.2)
                except queue.Empty:
                    continue
                if recognizer.AcceptWaveform(chunk):
                    text = json.loads(recognizer.Result()).get('text', '').strip()
                    if text:
                        listening.clear()
                        inputs.put((time.monotonic(), text))
    except Exception as exc:
        print(f'Microphone unavailable: {exc}. Typed input remains available.', flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model', help='cloud model name; defaults to OLLAMA_MODEL or gemma4:31b')
    parser.add_argument('--no-voice', action='store_true', help='typed input only')
    parser.add_argument('--mute', action='store_true', help='text replies only')
    parser.add_argument('--device', help='microphone name or index')
    parser.add_argument('--models', action='store_true', help='list cloud model names, then exit')
    parser.add_argument('--check', action='store_true', help='test cloud credentials/model, then exit')
    args = parser.parse_args()
    try:
        client = OllamaCloud(args.model)
        if args.models:
            print('\n'.join(client.models()))
            return 0
        if args.check:
            print(client.check())
            return 0
    except CloudError as exc:
        print(f'Cloud setup: {exc}', file=sys.stderr)
        return 1
    speaker = None if args.mute else LocalSpeaker()
    inputs = queue.Queue()
    replies = queue.Queue()
    done = threading.Event()
    listening = threading.Event()
    listening.set()
    history = []
    generation = 0
    pending = None
    request_thread = None

    def keyboard():
        while not done.is_set():
            try: text = input()
            except EOFError:
                inputs.put((time.monotonic(), '/quit'))
                return
            if text.strip(): inputs.put((time.monotonic(), text))

    def ask(token, text, previous):
        try: replies.put((token, text, client.reply(text, previous), None))
        except CloudError as exc: replies.put((token, text, None, str(exc)))
        except Exception: replies.put((token, text, None, 'Unexpected cloud request failure; try again.'))

    print(f'G1 CLOUD CONVERSATION — {client.model}\nQuestions go to Ollama Cloud; replies play on your Mac.\n'
          'Type /stop to interrupt, /reset to clear memory, /quit to exit. No robot movement.\n'
          'Microphone pauses during requests/replies; typed controls always work.', flush=True)
    threading.Thread(target=keyboard, daemon=True).start()
    if not args.no_voice:
        device = int(args.device) if args.device and args.device.isdigit() else args.device
        threading.Thread(target=microphone_worker, args=(inputs, done, listening, speaker, device), daemon=True).start()
    try:
        while not done.is_set():
            while not replies.empty():
                token, question, answer, error = replies.get()
                if token != pending:
                    continue
                pending = None
                if error:
                    print(f'Cloud: {error}', flush=True)
                else:
                    history.extend([{'role': 'user', 'content': question}, {'role': 'assistant', 'content': answer}])
                    history[:] = history[-16:]
                    if speaker:
                        speaker.speak(answer)
                    else:
                        print('G1: ' + answer, flush=True)
                print('Ready for your next question after speech finishes.', flush=True)
            try:
                timestamp, text = inputs.get(timeout=.05)
            except queue.Empty:
                if pending is None and not (speaker and speaker.is_speaking()):
                    listening.set()
                continue
            command = control(text)
            if command == 'quit':
                break
            if command in ('stop', 'reset'):
                generation += 1
                pending = None
                if speaker: speaker.stop()
                if command == 'reset': history.clear()
                print('Stopped. Pending response discarded.' if command == 'stop' else 'Conversation memory cleared.', flush=True)
                continue
            if command == 'help':
                print('Ask any question. /stop, /reset, /quit. Use --no-voice for typed input.', flush=True)
                continue
            if time.monotonic() - timestamp > 10:
                print('Old input discarded; please ask again.', flush=True)
                continue
            if (request_thread and request_thread.is_alive()) or pending is not None or (speaker and speaker.is_speaking()):
                print('Still thinking/speaking. Wait, or type /stop. This question was not queued.', flush=True)
                continue
            listening.clear()
            generation += 1
            pending = generation
            print(f'You: {text}\nG1 is thinking...', flush=True)
            request_thread = threading.Thread(target=ask, args=(pending, text, list(history)), daemon=True)
            request_thread.start()
    except KeyboardInterrupt:
        pass
    finally:
        done.set()
        if speaker: speaker.close()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
