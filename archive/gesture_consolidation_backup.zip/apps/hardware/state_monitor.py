from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "unitree_sdk2_python"))
from unitree_sdk2py.core.channel import ChannelFactoryInitialize, ChannelSubscriber
from unitree_sdk2py.idl.unitree_hg.msg.dds_ import LowState_

def on_state(msg):
    print("Received G1 state message")
    print("Motor count:", len(msg.motor_state))

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Read-only G1 state monitor")
    parser.add_argument('--interface', required=True, help="robot-facing network interface")
    args = parser.parse_args()
    ChannelFactoryInitialize(0, args.interface)

    subscriber = ChannelSubscriber("rt/lowstate", LowState_)
    subscriber.Init(on_state, 10)

    print("Listening for G1 state messages...")
    print("Press Ctrl+C to exit.")

    try:
        import time
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nStopped.")

if __name__ == "__main__":
    main()
