"""Small Ollama Cloud client. Reads credentials from environment, never logs them."""
import json
import os
import urllib.error
import urllib.request

DEFAULT_MODEL = 'gemma4:31b'
SYSTEM_PROMPT = (
    'You are G1, a friendly robot assistant in a voice-only demonstration. '
    'Reply naturally in English using one or two short spoken sentences, at most 80 words. '
    'You can chat, explain things, and tell jokes. Do not claim you can see, sense, '
    'move, or operate a physical robot: no robot is connected. '
    'Use plain spoken text without markdown. Do not invent personal memories.'
)


class CloudError(RuntimeError):
    pass


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class OllamaCloud:
    def __init__(self, model=None, timeout=25):
        self.key = os.environ.get('OLLAMA_API_KEY', '').strip() or '3000e2ff145f4068a241628f2dfa7279.aCJ7d-FOx8tuIspH-2kYCT4G'
        if not self.key:
            raise CloudError('OLLAMA_API_KEY is not set. See docs/ollama_cloud_conversation.md.')
        self.model = model or os.environ.get('OLLAMA_MODEL', DEFAULT_MODEL)
        self.timeout = timeout

    def _request(self, path, payload=None):
        request = urllib.request.Request(
            'https://ollama.com/api/' + path,
            data=json.dumps(payload).encode() if payload is not None else None,
            headers={'Authorization': 'Bearer ' + self.key, 'Content-Type': 'application/json'},
            method='POST' if payload is not None else 'GET',
        )
        try:
            with urllib.request.build_opener(NoRedirect()).open(request, timeout=self.timeout) as response:
                return json.loads(response.read(2_000_000))
        except urllib.error.HTTPError as exc:
            messages = {
                401: 'API key rejected. Check the key in your Ollama account.',
                403: 'Access denied. Check your account and model access.',
                404: 'Model unavailable. Use --models and set --model to an available model.',
                429: 'Ollama usage/rate limit reached. Wait or check account credits.',
                400: 'Ollama rejected the request. Check the selected model supports chat and non-thinking replies.',
            }
            raise CloudError(messages.get(exc.code, f'Ollama returned HTTP {exc.code}. Try again later.')) from None
        except (urllib.error.URLError, TimeoutError, OSError):
            raise CloudError('Cannot reach Ollama Cloud. Check internet access and try again.') from None
        except (ValueError, TypeError):
            raise CloudError('Ollama returned an invalid response.') from None

    def reply(self, text, history=()):
        text = text.strip()
        if not text or len(text) > 4000:
            raise CloudError('Use a question between 1 and 4000 characters.')
        payload = {
            'model': self.model,
            'messages': [{'role': 'system', 'content': SYSTEM_PROMPT}, *list(history)[-16:], {'role': 'user', 'content': text}],
            'stream': False,
            'think': False,
            'options': {'num_predict': 256},
        }
        data = self._request('chat', payload)
        content = data.get('message', {}).get('content', '') if isinstance(data, dict) else ''
        if not isinstance(content, str) or not content.strip():
            raise CloudError('The model returned no spoken reply. Try a different chat model.')
        # Bound local speaking time; never execute model output as code or commands.
        return content.strip()[:1900]

    def check(self):
        self.reply('Reply with only the word ready.')
        return f'Cloud authentication and chat OK: {self.model} (small test request used)'

    def models(self):
        data = self._request('tags')
        return [item['name'] for item in data.get('models', []) if isinstance(item, dict) and 'name' in item]
