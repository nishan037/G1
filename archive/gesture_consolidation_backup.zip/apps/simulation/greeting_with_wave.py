"""Say an introduction and wave together in MuJoCo. No robot connection needed."""
import argparse
from pathlib import Path
import queue
import sys
import threading
import time

sys.path.insert(0, str(Path(__file__).resolve().parent))
import voice_gesture_simulator as sim

INTRODUCTION = 'Hello! I am G one, your robot assistant. Welcome! It is nice to meet you.'
COMMANDS = {
    'greet': ('hello', 'say hello', 'introduce yourself', 'greet', 'greet me', 'wave hello'),
    'stop': ('stop', 'cancel', 'stop moving'),
    'help': ('help', 'show help', 'list commands'),
    'quit': ('quit', 'exit', 'close simulator'),
}


def greet(gestures, speaker, now, text=INTRODUCTION):
    """Schedule speech without waiting for it; start raising the arm this frame."""
    if gestures.action is not None or speaker.is_speaking():
        print('Greeting in progress. Wait, or type stop before trying again.', flush=True)
        return False
    if not speaker.speak(text):
        return False
    # Existing wave has a one-second rest lead-in. Skip that hold so the arm
    # starts rising at the same time speech is requested.
    gestures.start('wave', now - 1.0)
    gestures.update(now)
    return True


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--no-voice', action='store_true', help='typed commands only')
    parser.add_argument('--device', help='microphone index or name')
    parser.add_argument('--text', default=INTRODUCTION, help='custom introduction')
    parser.add_argument('--demo', action='store_true', help='greet automatically once after opening')
    parser.add_argument('--list', action='store_true')
    args = parser.parse_args()
    if args.list:
        print('hello / say hello / introduce yourself / wave hello: speak AND wave\nstop | help | quit')
        return
    sim.ALIASES = COMMANDS
    gestures = sim.Gestures()
    speaker = sim.LocalSpeaker()
    commands = queue.SimpleQueue()
    done = threading.Event()
    device = int(args.device) if args.device and args.device.isdigit() else args.device
    threading.Thread(target=sim.keyboard_worker, args=(commands, done), daemon=True).start()
    if not args.no_voice:
        threading.Thread(target=sim.voice_worker, args=(commands, done, device, speaker), daemon=True).start()
    print('GREETING SIMULATOR — say or type hello to speak and wave together.\nstop | help | quit', flush=True)
    demo_at = time.monotonic() + 2 if args.demo else None
    try:
        with sim.mujoco.viewer.launch_passive(gestures.model, gestures.data) as viewer:
            viewer.cam.lookat[:] = [0, 0, .9]
            viewer.cam.distance = 2.5
            viewer.cam.azimuth = 15
            viewer.cam.elevation = -10
            while viewer.is_running() and not done.is_set():
                now = time.monotonic()
                gestures.update(now)
                if demo_at is not None and now >= demo_at:
                    commands.put('greet')
                    demo_at = None
                while not commands.empty():
                    action = commands.get()
                    if action == 'greet':
                        greet(gestures, speaker, now, args.text)
                    elif action == 'stop':
                        speaker.stop()
                        gestures.start('stop', now)
                    elif action == 'help':
                        print('Say hello, introduce yourself, or wave hello. All speak and wave together. Type stop to interrupt.', flush=True)
                    elif action == 'quit':
                        done.set()
                caption = 'GREETING: speech + wave\nSay hello | introduce yourself | stop | quit\n'
                caption += speaker.caption or 'Ready; both arms resting down.'
                viewer.set_texts((sim.mujoco.mjtFontScale.mjFONTSCALE_100,
                                  sim.mujoco.mjtGridPos.mjGRID_TOPLEFT, caption, ''))
                viewer.sync()
                time.sleep(.02)
    except KeyboardInterrupt:
        pass
    finally:
        done.set()
        speaker.close()


if __name__ == '__main__':
    main()
