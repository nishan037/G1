"""Readiness checks for G1 launch targets. Never sends robot motion commands."""
import argparse
import importlib.util
import json
import socket
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
TARGETS = ('conversation', 'greeting', 'voice-sim', 'wave', 'physics', 'static', 'control', 'hardware', 'state', 'voice', 'vision', 'speak')
RESULT_PREFIX = 'G1_PREFLIGHT_RESULT='


def worker(args):
    results = []

    def check(label, fn):
        try:
            detail = fn()
            results.append({'status': 'PASS', 'check': label, 'detail': str(detail or 'OK')})
            return True
        except Exception as exc:
            results.append({'status': 'FAIL', 'check': label, 'detail': str(exc)})
            return False

    def skip(label, reason):
        results.append({'status': 'SKIP', 'check': label, 'detail': reason})

    def require(path):
        if not path.exists():
            raise RuntimeError(f'Missing: {path}')
        return path

    hardware = args.target in ('hardware', 'state')
    graphics = args.target in ('greeting', 'voice-sim', 'wave', 'physics', 'static', 'control')
    speech = not args.no_voice and (args.target in ('conversation', 'greeting', 'voice-sim', 'voice', 'control') or (args.target == 'hardware' and args.arm))
    check('Python environment', lambda: f'{sys.executable} (Python {sys.version.split()[0]})')
    modules = [] if args.target in ('speak', 'conversation') else ['cv2', 'ultralytics'] if args.target == 'vision' else ['mujoco', 'numpy']
    if hardware:
        sys.path.insert(0, str(ROOT / 'unitree_sdk2_python'))
        modules += ['cyclonedds', 'unitree_sdk2py.core.channel', 'unitree_sdk2py.g1.arm.g1_arm_action_client']
    if args.target == 'speak' or (args.target in ('conversation', 'greeting', 'voice-sim', 'control') and not args.mute):
        def speech_output():
            import shutil
            engine = shutil.which('say')
            if not engine:
                raise RuntimeError('macOS say engine missing; use --mute for the simulator')
            return 'macOS say available; audible output still depends on speaker/volume settings'
        check('Local speech output', speech_output)
    if speech:
        modules += ['vosk', 'sounddevice']
    dependencies_ok = check('Required Python packages', lambda: [__import__(name, fromlist=['*']).__name__ for name in modules])
    if graphics:
        model_path = ROOT / 'unitree_mujoco/unitree_robots/g1/scene_23dof.xml'
        if dependencies_ok and check('G1 model files', lambda: require(model_path)):
            def render():
                import mujoco
                model = mujoco.MjModel.from_xml_path(str(model_path))
                data = mujoco.MjData(model)
                mujoco.mj_resetDataKeyframe(model, data, 0)
                mujoco.mj_forward(model, data)
                with mujoco.Renderer(model, height=64, width=64) as renderer:
                    renderer.update_scene(data)
                    frame = renderer.render()
                    if frame.shape != (64, 64, 3):
                        raise RuntimeError('Unexpected graphics output')
                return 'Model loaded and offscreen frame rendered'
            check('MuJoCo graphics', render)
            check('macOS viewer runtime', lambda: require(ROOT / '.venv-g1/bin/mjpython'))
    else:
        skip('Simulation graphics', 'Not needed for this target')
    if speech and dependencies_ok:
        def speech_model():
            from vosk import Model, SetLogLevel
            SetLogLevel(-1)
            path = ROOT / 'models/speech/vosk-model-small-en-us-0.15'
            require(path)
            model = Model(str(path))
            return f'Vosk model loaded: {path.name}'
        check('Offline speech model', speech_model)
        def microphone():
            import sounddevice as sd
            device = int(args.device) if args.device and args.device.isdigit() else args.device
            info = sd.query_devices(device, 'input')
            rate = int(info['default_samplerate'])
            with sd.RawInputStream(device=device, samplerate=rate, channels=1, dtype='int16') as stream:
                audio, overflow = stream.read(max(1, rate // 10))
                if not len(audio):
                    raise RuntimeError('Microphone returned no samples')
            return f'{info["name"]}: stream opened; sample discarded (speech accuracy not measured)'
        check('Microphone access', microphone)
    else:
        skip('Speech and microphone', 'Disabled or not needed; hardware probe is read-only')
    if args.target == 'vision' and dependencies_ok:
        def vision_model():
            from ultralytics import YOLO
            path = require(ROOT / 'models/vision/yolo11n.pt')
            YOLO(str(path))
            return path.name
        check('Object detection model', vision_model)
        def camera():
            import cv2
            cap = cv2.VideoCapture(0)
            try:
                if not cap.isOpened():
                    raise RuntimeError('Camera unavailable; check macOS camera permission')
                ok, frame = cap.read()
                if not ok or frame is None:
                    raise RuntimeError('Camera opened but no frame received')
                return 'Camera opened; test frame discarded'
            finally:
                cap.release()
        check('Camera access', camera)
    if args.target == 'conversation':
        def cloud():
            sys.path.insert(0, str(ROOT / 'apps/ai'))
            from ollama_cloud_client import OllamaCloud
            return OllamaCloud(args.model).check()
        check('Ollama Cloud API key, model, and connection', cloud)
    if hardware:
        names = {name for _, name in socket.if_nameindex()} - {'lo', 'lo0'}
        def interface():
            if not args.interface:
                raise RuntimeError('Specify --interface. Available: ' + ', '.join(sorted(names)))
            if args.interface not in names:
                raise RuntimeError(f'Interface {args.interface!r} unavailable. Available: {sorted(names)}')
            return args.interface
        interface_ok = check('Robot network interface', interface)
        if dependencies_ok and interface_ok:
            def robot():
                if args.target == 'state':
                    import threading
                    from unitree_sdk2py.core.channel import ChannelFactoryInitialize, ChannelSubscriber
                    from unitree_sdk2py.idl.unitree_hg.msg.dds_ import LowState_
                    ChannelFactoryInitialize(0, args.interface)
                    ready = threading.Event()
                    subscriber = ChannelSubscriber('rt/lowstate', LowState_)
                    subscriber.Init(lambda msg: ready.set() if len(msg.motor_state) >= 23 else None, 10)
                    try:
                        if not ready.wait(5):
                            raise RuntimeError('No G1 state received within 5 seconds; check PC/robot network and robot services')
                        return 'G1 state received; no motion commands sent'
                    finally:
                        subscriber.Close()
                path = ROOT / 'apps/hardware/voice_robot_control.py'
                spec = importlib.util.spec_from_file_location('g1_preflight_bridge', path)
                bridge = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(bridge)
                controller, subscriber = bridge.connect(args.interface, args.enable_walking)
                try:
                    if not controller.healthy(time.monotonic()):
                        raise RuntimeError('Robot state stream became stale during discovery')
                    if not controller.actions:
                        raise RuntimeError('Action service replied but no presets matched the installed SDK')
                    if args.arm and 'release arm' not in controller.actions:
                        raise RuntimeError('Release-arm action is required to enable physical gestures')
                    return f'Live state + action service OK; {len(controller.actions)} matched presets' + ('; locomotion state query OK' if args.enable_walking else '') + '; no motion sent'
                finally:
                    # Do not call controller.stop(): preflight must never write motion commands.
                    subscriber.Close()
            check('PC-to-G1 access and services', robot)
        else:
            skip('PC-to-G1 access and services', 'Fix interface/packages first')
    else:
        skip('PC-to-G1 access', 'Robot connection is not required for simulation/local apps')
    return results


def run_checks(target, extra=()):
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('--interface')
    parser.add_argument('--device')
    parser.add_argument('--model')
    parser.add_argument('--no-voice', action='store_true')
    parser.add_argument('--mute', action='store_true')
    parser.add_argument('--arm', action='store_true')
    parser.add_argument('--enable-walking', action='store_true')
    parser.add_argument('--hardware', action='store_true')
    parser.add_argument('--list', action='store_true')
    flags, _ = parser.parse_known_args(extra)
    effective = 'hardware' if target == 'control' and flags.hardware else target
    runtime = ROOT / ('.venv/bin/python' if effective == 'vision' else '.venv-g1/bin/python')
    print(f'\nG1 PRE-FLIGHT — {effective}', flush=True)
    rows = []
    if not runtime.is_file():
        rows.append({'status': 'FAIL', 'check': 'Python environment', 'detail': f'Missing runtime: {runtime}'})
    else:
        command = [str(runtime), str(ROOT / 'preflight.py'), '--worker', '--target', effective]
        for name in ('interface', 'device', 'model'):
            if getattr(flags, name) is not None:
                command += ['--' + name, getattr(flags, name)]
        for name in ('no_voice', 'mute', 'arm', 'enable_walking'):
            if getattr(flags, name):
                command.append('--' + name.replace('_', '-'))
        # Listing hardware actions remains read-only even when --arm was supplied.
        if flags.list and '--arm' in command:
            command.remove('--arm')
        try:
            result = subprocess.run(command, cwd=ROOT, text=True, capture_output=True, timeout=40)
            line = next((s for s in reversed(result.stdout.splitlines()) if s.startswith(RESULT_PREFIX)), None)
            if line:
                rows = json.loads(line[len(RESULT_PREFIX):])
            else:
                raise RuntimeError((result.stderr or result.stdout or f'Worker exited {result.returncode}')[-1600:])
        except Exception as exc:
            rows.append({'status': 'FAIL', 'check': 'Preflight execution', 'detail': str(exc)})
    for row in rows:
        print(f'[{row["status"]}] {row["check"]}: {row["detail"]}', flush=True)
    passed = bool(rows) and not any(r['status'] == 'FAIL' for r in rows)
    print('READY — required checks passed.' if passed else 'NOT READY — fix the failed checks before launching.', flush=True)
    print('Checks reflect current access, not physical clearance or robot motion validation.\n', flush=True)
    return passed


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--target', choices=TARGETS, default='voice-sim')
    parser.add_argument('--worker', action='store_true', help=argparse.SUPPRESS)
    parser.add_argument('--interface')
    parser.add_argument('--device')
    parser.add_argument('--model')
    parser.add_argument('--no-voice', action='store_true')
    parser.add_argument('--mute', action='store_true')
    parser.add_argument('--arm', action='store_true')
    parser.add_argument('--enable-walking', action='store_true')
    args = parser.parse_args()
    if args.worker:
        results = worker(args)
        print(RESULT_PREFIX + json.dumps(results), flush=True)
        return 0 if not any(r['status'] == 'FAIL' for r in results) else 1
    return 0 if run_checks(args.target, sys.argv[1:]) else 1


if __name__ == '__main__':
    raise SystemExit(main())
