from pathlib import Path

import time
import math
import threading

import mujoco
import mujoco.viewer

MODEL_PATH = str(next(parent for parent in Path(__file__).resolve().parents if (parent / 'launch.py').is_file() and (parent / 'unitree_mujoco').is_dir()) / 'unitree_mujoco/unitree_robots/g1/scene_23dof.xml')

model = mujoco.MjModel.from_xml_path(MODEL_PATH)
data = mujoco.MjData(model)

mujoco.mj_resetDataKeyframe(model, data, 0)
mujoco.mj_forward(model, data)

initial_pose = data.qpos.copy()

# Right arm joint addresses and limits
joints = {}

joint_names = [
    "right_shoulder_pitch_joint",
    "right_shoulder_roll_joint",
    "right_shoulder_yaw_joint",
    "right_elbow_joint",
    "right_wrist_roll_joint",
]

for name in joint_names:
    joint_id = mujoco.mj_name2id(
        model, mujoco.mjtObj.mjOBJ_JOINT, name
    )

    if joint_id < 0:
        raise RuntimeError(f"Joint not found: {name}")

    joints[name] = {
        "address": int(model.jnt_qposadr[joint_id]),
        "minimum": float(model.jnt_range[joint_id][0]),
        "maximum": float(model.jnt_range[joint_id][1]),
    }


def set_joint(name, angle):
    joint = joints[name]

    # Respect the XML model's joint limits.
    angle = max(
        joint["minimum"],
        min(joint["maximum"], angle)
    )

    data.qpos[joint["address"]] = angle


def smoothstep(x):
    x = max(0.0, min(1.0, x))
    return x * x * (3 - 2 * x)


# Relative to the robot's default standing pose.
# These are illustrative simulation angles,
# not validated physical G1 commands.
wave_offsets = {
    "right_shoulder_pitch_joint": -0.25,
    "right_shoulder_roll_joint": -1.15,
    "right_shoulder_yaw_joint": 0.25,
    "right_elbow_joint": 1.55,
    "right_wrist_roll_joint": 0.0,
}


def animate_wave(elapsed):
    data.qpos[:] = initial_pose

    # Raise arm during first second.
    if elapsed < 1.0:
        strength = smoothstep(elapsed)

    # Hold the raised pose while waving.
    elif elapsed < 3.5:
        strength = 1.0

    # Lower arm smoothly.
    else:
        strength = 1.0 - smoothstep(
            (elapsed - 3.5) / 1.0
        )

    for name, offset in wave_offsets.items():
        address = joints[name]["address"]
        base = initial_pose[address]

        angle = base + offset * strength

        # Side-to-side greeting motion.
        if (
            name == "right_shoulder_yaw_joint"
            and 1.0 <= elapsed < 3.5
        ):
            angle += (
                0.35
                * math.sin(2 * math.pi * 1.5 * (elapsed - 1.0))
            )

        set_joint(name, angle)

    mujoco.mj_forward(model, data)


gesture_requested = threading.Event()
running = threading.Event()
running.set()


def keyboard_listener():
    while running.is_set():
        try:
            command = input().strip().lower()
        except EOFError:
            break

        if command in ("w", "wave"):
            gesture_requested.set()

        elif command in ("q", "quit"):
            running.clear()
            break


threading.Thread(
    target=keyboard_listener,
    daemon=True
).start()

print("\nG1 Gesture Simulator")
print("Press W + Enter to wave")
print("Press Q + Enter to quit\n")

with mujoco.viewer.launch_passive(model, data) as viewer:
    wave_start = None

    while viewer.is_running() and running.is_set():

        if gesture_requested.is_set():
            gesture_requested.clear()
            wave_start = time.monotonic()
            print("G1: Waving hello!")

        if wave_start is not None:
            elapsed = time.monotonic() - wave_start

            if elapsed <= 4.5:
                animate_wave(elapsed)
            else:
                data.qpos[:] = initial_pose
                mujoco.mj_forward(model, data)
                wave_start = None
                print("Gesture completed")

        viewer.sync()
        time.sleep(0.02)

running.clear()
print("Simulator closed")

