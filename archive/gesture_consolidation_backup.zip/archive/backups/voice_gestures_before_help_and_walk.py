"""Offline Vosk -> G1 kinematic gesture demonstrations. No hardware commands.

Run with .venv-g1/bin/mjpython gestures_with_voice.py
Use --no-voice for typed commands, --demo to cycle, --list for phrases.
SDK action names are a vocabulary reference, not official motion trajectories.
"""
import argparse
import json
import math
from pathlib import Path
import queue
import re
import threading
import time

import mujoco
import mujoco.viewer
import numpy as np

ROOT = next(parent for parent in Path(__file__).resolve().parents if (parent / 'launch.py').is_file() and (parent / 'unitree_mujoco').is_dir())
# Also permits keeping this file in the user's current G1 workspace.
if not (ROOT / 'unitree_mujoco').exists():
    ROOT = next(parent for parent in Path(__file__).resolve().parents if (parent / 'launch.py').is_file() and (parent / 'unitree_mujoco').is_dir())

# Every action in the installed G1ArmActionClient.action_map is represented.
ALIASES = {
    'wave': ('wave', 'wave hello', 'hello', 'say hello', 'wave your hand'),
    'face wave': ('face wave', 'wave near your face'),
    'high wave': ('high wave', 'wave high'),
    'left wave': ('left wave', 'wave left', 'wave your left hand'),
    'both wave': ('both wave', 'wave both hands', 'wave with both hands'),
    'shake hand': ('shake hand', 'shake hands', 'handshake', 'give me a handshake'),
    'hands up': ('hands up', 'raise both hands', 'raise your hands'),
    'right hand up': ('right hand up', 'raise your right hand'),
    'clap': ('clap', 'clap your hands', 'applause'),
    'high five': ('high five', 'give me a high five'),
    'hug': ('hug', 'give me a hug', 'open your arms'),
    'heart': ('heart', 'make a heart', 'show a heart'),
    'right heart': ('right heart', 'make a right heart'),
    'reject': ('reject', 'say no', 'no thank you'),
    'x-ray': ('x ray', 'x-ray', 'cross your arms'),
    'two-hand kiss': ('two hand kiss', 'two-hand kiss', 'blow a kiss', 'blow a kiss with both hands'),
    'left kiss': ('left kiss', 'blow a left kiss'),
    'right kiss': ('right kiss', 'blow a right kiss'),
    'release arm': ('release arm', 'release arms', 'arms down', 'rest', 'resting pose', 'reset'),
    'stop': ('stop', 'stop now', 'cancel', 'stop moving'),
    'help': ('help', 'list commands', 'what can you do'),
    'quit': ('quit', 'exit', 'close simulator'),
}
UNSUPPORTED = ('move forward', 'walk forward', 'go forward', 'move backward',
               'go back', 'turn left', 'turn right', 'sit', 'sit down',
               'stand up', 'squat', 'lie down', 'dance', 'jump')


def normalize(text):
    return re.sub(r'[^a-z0-9 ]+', ' ', text.lower()).strip()


def interpret_command(text):
    text = ' '.join(normalize(text).split())
    for prefix in ('hey g one', 'hey gee one', 'hey g1', 'g one', 'gee one', 'g1', 'hey robot', 'robot'):
        if text == prefix or text.startswith(prefix + ' '):
            text = text[len(prefix):].strip()
            break
    text = re.sub(r'^please\s+|\s+please$', '', text).strip()
    # Match whole utterances; do not execute "don't wave" or choose one of two actions.
    for action, phrases in ALIASES.items():
        if text in {normalize(p) for p in phrases}:
            return action
    if text in UNSUPPORTED:
        return 'unsupported'
    return None


def print_commands():
    print('\nSIMULATION: illustrative arm motions; fixed fingers; no hardware control.')
    print('Commands: ' + ', '.join(ALIASES))
    print('Say "G one, wave hello" or just "wave hello". Type commands here too.')
    print('Stop/arms down smoothly returns to rest. Walking is not implemented.\n', flush=True)


def ease(x):
    x = max(0.0, min(1.0, x))
    return x ** 3 * (10 - 15 * x + 6 * x * x)


class Gestures:
    def __init__(self):
        self.model = mujoco.MjModel.from_xml_path(str(ROOT / 'unitree_mujoco/unitree_robots/g1/scene_23dof.xml'))
        self.data = mujoco.MjData(self.model)
        mujoco.mj_resetDataKeyframe(self.model, self.data, 0)
        self.joints = {}
        for side in ('right', 'left'):
            for part in ('shoulder_pitch', 'shoulder_roll', 'shoulder_yaw', 'elbow', 'wrist_roll'):
                name = f'{side}_{part}_joint'
                j = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_JOINT, name)
                if j < 0:
                    raise RuntimeError(f'Missing joint: {name}')
                self.joints[name] = (int(self.model.jnt_qposadr[j]), *self.model.jnt_range[j])
        self.rest = self.data.qpos.copy()
        for side in ('right', 'left'):
            self.arm(self.rest, side, [0, -.10, 0, math.pi / 2, 0])
        self.data.qpos[:] = self.rest
        mujoco.mj_forward(self.model, self.data)
        self.action = None
        self.started = 0.0
        self.duration = 0.0
        self.start_pose = self.rest.copy()

    def arm(self, pose, side, angles):
        for part, angle in zip(('shoulder_pitch', 'shoulder_roll', 'shoulder_yaw', 'elbow', 'wrist_roll'), angles):
            if side == 'left' and part in ('shoulder_roll', 'shoulder_yaw', 'wrist_roll'):
                angle = -angle
            address, lower, upper = self.joints[f'{side}_{part}_joint']
            pose[address] = np.clip(angle, lower, upper)

    def target(self, action, t):
        pose = self.rest.copy()
        wave = [-.30, -1.40, -1.50, .10, 0]
        sides = ('left',) if action == 'left wave' else ('right', 'left') if action == 'both wave' else ('right',)
        if action in ('wave', 'face wave', 'high wave', 'left wave', 'both wave', 'right hand up', 'high five', 'hands up'):
            if action == 'hands up':
                sides = ('right', 'left')
            if action == 'face wave':
                wave = [-.55, -1.05, -1.50, -.15, 0]
            if action in ('high wave', 'hands up'):
                wave = [-.30, -1.95, -1.50, .35, 0]
            u = max(0., min(1., t / 3.))
            if 'wave' in action:
                wave[2] += .30 * math.sin(math.pi * u) ** 2 * math.sin(6 * math.pi * u)
            for side in sides:
                self.arm(pose, side, wave)
        elif action == 'shake hand':
            self.arm(pose, 'right', [-.45 + .09 * math.sin(4 * math.pi * t), -.20, 0, .25, 0])
        elif action in ('hug', 'clap', 'heart', 'right heart', 'x-ray', 'reject'):
            angles = {
                'hug': [-.439, -1.280, .380, .146, 0],
                'clap': [-.595, .149, .088, -.152, 0],
                'heart': [-.855, .169, .011, -.370, 0],
                'right heart': [-.855, .28, .011, -.370, 0],
                'x-ray': [-.810, .522, .350, .084, 0],
                'reject': [-.70, -.4, -.5, .0, 0],
            }[action]
            if action == 'clap':
                # Bring fixed hands towards one another; no contact simulation.
                angles[1] -= .45 * (.5 - .5 * math.cos(2 * math.pi * t))
            if action == 'reject':
                angles[2] += .3 * math.sin(4 * math.pi * t)
            for side in (('right',) if action == 'right heart' else ('right', 'left')):
                self.arm(pose, side, angles)
        elif action in ('two-hand kiss', 'left kiss', 'right kiss'):
            sides = ('right', 'left') if action == 'two-hand kiss' else ('left',) if action == 'left kiss' else ('right',)
            reach = ease((t - .5) / 1.3)
            near = np.array([-1.422, .119, -.214, -.070, 0])
            away = np.array([-1.727, -.376, -.506, 1.699, 0])
            for side in sides:
                self.arm(pose, side, near + (away - near) * reach)
        return pose

    def start(self, action, now):
        if action in ('release arm', 'stop'):
            self.action = 'release arm'
            self.duration = 1.2
        else:
            if self.action is not None:
                print('Gesture in progress. Say "stop" first, or wait until it finishes.', flush=True)
                return
            self.action = action
            self.duration = 6.7
        self.start_pose = self.data.qpos.copy()
        self.started = now
        print(f'Action: {self.action}', flush=True)

    def update(self, now):
        if self.action is None:
            return
        t = max(0., now - self.started)
        if self.action == 'release arm':
            self.data.qpos[:] = self.start_pose + (self.rest - self.start_pose) * ease(t / self.duration)
        elif t < 1.0:
            self.data.qpos[:] = self.start_pose
        elif t < 2.5:
            target = self.target(self.action, 0.)
            self.data.qpos[:] = self.start_pose + (target - self.start_pose) * ease((t - 1.) / 1.5)
        elif t < 5.5:
            # Fade periodic motions in/out to meet transition poses continuously.
            phase = t - 2.5
            base = self.target(self.action, 0.)
            moving = self.target(self.action, phase)
            if self.action.endswith('kiss'):
                self.data.qpos[:] = moving
            else:
                blend = math.sin(math.pi * phase / 3.) ** 2
                self.data.qpos[:] = base + (moving - base) * blend
        else:
            end = self.target(self.action, 3. if self.action.endswith('kiss') else 0.)
            self.data.qpos[:] = end + (self.rest - end) * ease((t - 5.5) / 1.2)
        if t >= self.duration:
            self.data.qpos[:] = self.rest
            print('Finished; arms resting down.', flush=True)
            self.action = None
        mujoco.mj_forward(self.model, self.data)


def keyboard_worker(commands, done):
    while not done.is_set():
        try:
            line = input()
        except EOFError:
            return
        action = interpret_command(line)
        if action:
            commands.put(action)
        else:
            print('Unknown command. Type help for the command list.', flush=True)


def voice_worker(commands, done, device):
    try:
        import sounddevice as sd
        from vosk import Model, KaldiRecognizer, SetLogLevel
        SetLogLevel(-1)
        model_path = ROOT / 'models/speech/vosk-model-small-en-us-0.15'
        if not model_path.is_dir():
            raise RuntimeError(f'Speech model missing: {model_path}')
        speech_model = Model(str(model_path))
        # Constrained vocabulary helps the small offline recognizer distinguish gestures.
        phrases = {normalize(p) for variants in ALIASES.values() for p in variants}
        phrases.update(UNSUPPORTED)
        grammar = set(phrases)
        for prefix in ('g one', 'gee one', 'hey g one', 'hey robot'):
            grammar.update(prefix + ' ' + p for p in phrases)
        grammar.add('[unk]')
        info = sd.query_devices(device, 'input')
        rate = int(info['default_samplerate'])
        recognizer = KaldiRecognizer(speech_model, rate, json.dumps(sorted(grammar)))
        audio = queue.Queue(maxsize=32)

        def callback(indata, frames, timing, status):
            if status:
                print(f'Microphone: {status}', flush=True)
            try:
                audio.put_nowait(bytes(indata))
            except queue.Full:
                pass

        with sd.RawInputStream(device=device, samplerate=rate, blocksize=max(800, rate // 5),
                               dtype='int16', channels=1, callback=callback):
            print(f'VOICE READY — microphone: {info["name"]}. Say "G one, wave hello!"', flush=True)
            while not done.is_set():
                try:
                    chunk = audio.get(timeout=.2)
                except queue.Empty:
                    continue
                # Finalized utterances prevent partial phrases executing twice.
                if recognizer.AcceptWaveform(chunk):
                    text = json.loads(recognizer.Result()).get('text', '').strip()
                    if text:
                        action = interpret_command(text)
                        print(f'Heard: {text}' + (f' -> {action}' if action else ' (unrecognized)'), flush=True)
                        if action:
                            commands.put(action)
    except Exception as exc:
        print(f'Voice unavailable: {exc}\nAllow microphone access in macOS settings and restart, '
              'or use --devices / --device. Typed commands remain available.', flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--no-voice', action='store_true')
    parser.add_argument('--list', action='store_true', help='list supported voice commands and exit')
    parser.add_argument('--devices', action='store_true', help='list audio devices and exit')
    parser.add_argument('--device', help='microphone index or name')
    parser.add_argument('--demo', action='store_true', help='cycle through all gesture demonstrations')
    args = parser.parse_args()
    if args.list:
        print_commands()
        return
    if args.devices:
        import sounddevice as sd
        print(sd.query_devices())
        return
    device = int(args.device) if args.device and args.device.isdigit() else args.device
    gestures = Gestures()
    commands = queue.SimpleQueue()
    done = threading.Event()
    threading.Thread(target=keyboard_worker, args=(commands, done), daemon=True).start()
    if not args.no_voice:
        threading.Thread(target=voice_worker, args=(commands, done, device), daemon=True).start()
    print_commands()
    demo_actions = iter(a for a in ALIASES if a not in ('help', 'quit', 'stop', 'release arm'))
    next_demo = time.monotonic() + 2
    try:
        with mujoco.viewer.launch_passive(gestures.model, gestures.data) as viewer:
            viewer.cam.lookat[:] = [0, 0, .9]
            viewer.cam.distance = 2.5
            viewer.cam.azimuth = 15
            viewer.cam.elevation = -10
            while viewer.is_running() and not done.is_set():
                now = time.monotonic()
                # Advance before handling stop so the return starts at the current pose.
                gestures.update(now)
                if args.demo and gestures.action is None and now >= next_demo:
                    action = next(demo_actions, None)
                    if action:
                        commands.put(action)
                    else:
                        args.demo = False
                    next_demo = now + 7.7
                while not commands.empty():
                    action = commands.get()
                    if action == 'quit':
                        done.set()
                    elif action == 'help':
                        print_commands()
                    elif action == 'unsupported':
                        print('Locomotion/body action unavailable: this viewer implements arm gestures only.', flush=True)
                    else:
                        if action == 'stop':
                            args.demo = False
                        gestures.start(action, now)
                viewer.sync()
                time.sleep(.02)
    except KeyboardInterrupt:
        pass
    finally:
        done.set()


if __name__ == '__main__':
    main()
