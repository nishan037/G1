from pathlib import Path

import time
import math
import threading
import mujoco
import mujoco.viewer

MODEL_PATH = str(next(parent for parent in Path(__file__).resolve().parents if (parent / 'launch.py').is_file() and (parent / 'unitree_mujoco').is_dir()) / 'unitree_mujoco/unitree_robots/g1/scene_23dof.xml')

model = mujoco.MjModel.from_xml_path(MODEL_PATH)
data = mujoco.MjData(model)

mujoco.mj_resetDataKeyframe(model, data, 0)
mujoco.mj_forward(model, data)

print("Loaded G1 model")
print("Available right arm joints:")

# Find the actual joint names in the loaded model.
right_arm = {}

for joint_id in range(model.njnt):
    name = mujoco.mj_id2name(
        model, mujoco.mjtObj.mjOBJ_JOINT, joint_id
    )

    if name and "right" in name and (
        "shoulder" in name or "elbow" in name
    ):
        right_arm[name] = model.jnt_qposadr[joint_id]
        print(" ", name)

initial_pose = data.qpos.copy()

# Shared gesture state
gesture_requested = threading.Event()
running = threading.Event()
running.set()


def keyboard_listener():
    while running.is_set():
        try:
            command = input().strip().lower()
        except EOFError:
            break

        if command in ("w", "wave"):
            gesture_requested.set()
        elif command in ("q", "quit"):
            running.clear()
            break


def wave_pose(t):
    """Animate selected right-arm joints."""
    data.qpos[:] = initial_pose

    # A simple arm-raising and waving motion.
    for name, address in right_arm.items():
        if "shoulder_pitch" in name:
            data.qpos[address] = -0.8
        elif "shoulder_roll" in name:
            data.qpos[address] = -0.5
        elif "elbow" in name:
            data.qpos[address] = 1.0 + 0.35 * math.sin(2 * math.pi * t)

    mujoco.mj_forward(model, data)


threading.Thread(
    target=keyboard_listener,
    daemon=True
).start()

print("\nG1 Gesture Simulator")
print("Type 'w' and press Enter to wave.")
print("Type 'q' and press Enter to quit.\n")

with mujoco.viewer.launch_passive(model, data) as viewer:
    wave_start = None

    while viewer.is_running() and running.is_set():
        if gesture_requested.is_set():
            gesture_requested.clear()
            wave_start = time.monotonic()
            print("Executing WAVE gesture")

        if wave_start is not None:
            elapsed = time.monotonic() - wave_start

            if elapsed < 3.0:
                wave_pose(elapsed)
            else:
                data.qpos[:] = initial_pose
                mujoco.mj_forward(model, data)
                wave_start = None
                print("Wave completed")

        viewer.sync()
        time.sleep(0.02)

running.clear()
print("Gesture simulator closed")

