from pathlib import Path

import time
import mujoco
import mujoco.viewer

MODEL_PATH = str(next(parent for parent in Path(__file__).resolve().parents if (parent / 'launch.py').is_file() and (parent / 'unitree_mujoco').is_dir()) / 'unitree_mujoco/unitree_robots/g1/scene_23dof.xml')

print("Loading Unitree G1 23-DOF simulation...")

model = mujoco.MjModel.from_xml_path(MODEL_PATH)
data = mujoco.MjData(model)

# Load the initial robot pose
mujoco.mj_resetDataKeyframe(model, data, 0)
mujoco.mj_forward(model, data)

# Freeze the initial pose for a visual demonstration.
# No physics steps are executed.
print("G1 loaded in static demonstration mode.")
print("Actuators:", model.nu)

with mujoco.viewer.launch_passive(model, data) as viewer:
    while viewer.is_running():
        viewer.sync()
        time.sleep(0.02)

print("Simulator closed.")

