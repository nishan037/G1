from pathlib import Path

import json
import queue
import sys

import sounddevice as sd
from vosk import Model, KaldiRecognizer

MODEL_PATH = str(next(parent for parent in Path(__file__).resolve().parents if (parent / 'launch.py').is_file() and (parent / 'unitree_mujoco').is_dir()) / 'models/speech/vosk-model-small-en-us-0.15')
SAMPLE_RATE = 16000

audio_queue = queue.Queue()

# Offline simulation only: no Unitree SDK commands
COMMANDS = {
    "move forward": "FORWARD",
    "walk forward": "FORWARD",
    "go forward": "FORWARD",
    "move backward": "BACKWARD",
    "go back": "BACKWARD",
    "turn left": "TURN_LEFT",
    "turn right": "TURN_RIGHT",
    "stop": "STOP",
    "wave": "WAVE",
    "say hello": "SAY_HELLO",
}

def audio_callback(indata, frames, time_info, status):
    if status:
        print(status, file=sys.stderr)
    audio_queue.put(bytes(indata))

def interpret_command(text):
    text = text.lower().strip()

    # Optional wake phrase
    for prefix in ("hey g one", "g one", "g1", "hey robot"):
        if text.startswith(prefix):
            text = text[len(prefix):].strip()
            break

    # Longer phrases first to avoid accidental matches
    for phrase in sorted(COMMANDS, key=len, reverse=True):
        if phrase in text:
            return COMMANDS[phrase]

    return None

def main():
    print("Loading offline speech model...")
    model = Model(MODEL_PATH)

    recognizer = KaldiRecognizer(model, SAMPLE_RATE)

    print("\nG1 Voice Assistant — SIMULATION MODE")
    print("Try: move forward, turn left, wave, stop")
    print("Press Ctrl+C to exit.\n")

    with sd.RawInputStream(
        samplerate=SAMPLE_RATE,
        blocksize=8000,
        dtype="int16",
        channels=1,
        callback=audio_callback,
    ):
        while True:
            data = audio_queue.get()

            if recognizer.AcceptWaveform(data):
                result = json.loads(recognizer.Result())
                text = result.get("text", "").strip()

                if not text:
                    continue

                print(f"Heard: {text}")

                command = interpret_command(text)

                if command:
                    print(f"[SIMULATION] G1 action: {command}\n")
                else:
                    print("Command not recognized\n")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nVoice assistant stopped.")

