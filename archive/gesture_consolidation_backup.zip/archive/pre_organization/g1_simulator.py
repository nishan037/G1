from pathlib import Path

import time
import mujoco
import mujoco.viewer

MODEL_PATH = str(next(parent for parent in Path(__file__).resolve().parents if (parent / 'launch.py').is_file() and (parent / 'unitree_mujoco').is_dir()) / 'unitree_mujoco/unitree_robots/g1/scene_23dof.xml')

print("Loading Unitree G1 simulation...")

model = mujoco.MjModel.from_xml_path(MODEL_PATH)
data = mujoco.MjData(model)

# Initialize the model to its default pose.
mujoco.mj_resetDataKeyframe(model, data, 0)
mujoco.mj_forward(model, data)

print("G1 model loaded successfully!")
print("Degrees of freedom:", model.nv)
print("Actuators:", model.nu)
print("Opening 3D viewer...")

with mujoco.viewer.launch_passive(model, data) as viewer:
    while viewer.is_running():
        mujoco.mj_step(model, data)
        viewer.sync()
        time.sleep(model.opt.timestep)

print("G1 simulation closed.")


