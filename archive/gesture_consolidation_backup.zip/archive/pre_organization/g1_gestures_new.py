
import time
import math
import threading
from pathlib import Path

import mujoco
import mujoco.viewer

MODEL_PATH = str(next(parent for parent in Path(__file__).resolve().parents if (parent / 'launch.py').is_file() and (parent / 'unitree_mujoco').is_dir()) / 'unitree_mujoco/unitree_robots/g1/scene_23dof.xml')

model = mujoco.MjModel.from_xml_path(MODEL_PATH)
data = mujoco.MjData(model)

mujoco.mj_resetDataKeyframe(model, data, 0)
mujoco.mj_forward(model, data)

# A relaxed arms-down starting pose. In this model, elbow near pi/2
# aligns the forearm with the hanging upper arm.
for side, roll in (("right", -0.10), ("left", 0.10)):
    for part, angle in (("shoulder_pitch", 0.0), ("shoulder_roll", roll),
                        ("shoulder_yaw", 0.0), ("elbow", math.pi / 2),
                        ("wrist_roll", 0.0)):
        joint_id = mujoco.mj_name2id(
            model, mujoco.mjtObj.mjOBJ_JOINT, f"{side}_{part}_joint"
        )
        if joint_id < 0:
            raise RuntimeError(f"Missing resting-pose joint: {side}_{part}")
        lower, upper = model.jnt_range[joint_id]
        data.qpos[model.jnt_qposadr[joint_id]] = max(lower, min(upper, angle))
mujoco.mj_forward(model, data)
initial_pose = data.qpos.copy()

# Right arm joint addresses and limits
joints = {}

joint_names = [
    "right_shoulder_pitch_joint",
    "right_shoulder_roll_joint",
    "right_shoulder_yaw_joint",
    "right_elbow_joint",
    "right_wrist_roll_joint",
]

for name in joint_names:
    joint_id = mujoco.mj_name2id(
        model, mujoco.mjtObj.mjOBJ_JOINT, name
    )

    if joint_id < 0:
        raise RuntimeError(f"Joint not found: {name}")

    joints[name] = {
        "address": int(model.jnt_qposadr[joint_id]),
        "minimum": float(model.jnt_range[joint_id][0]),
        "maximum": float(model.jnt_range[joint_id][1]),
    }


def set_joint(name, angle):
    joint = joints[name]

    # Respect the XML model's joint limits.
    angle = max(
        joint["minimum"],
        min(joint["maximum"], angle)
    )

    data.qpos[joint["address"]] = angle


def smoothstep(x):
    """Quintic easing: zero speed and acceleration at each endpoint."""
    x = max(0.0, min(1.0, x))
    return x * x * x * (10.0 - 15.0 * x + 6.0 * x * x)


REST_SECONDS = 1.0
RAISE_SECONDS = 1.5
WAVE_SECONDS = 3.0
LOWER_SECONDS = 1.2
GESTURE_SECONDS = REST_SECONDS + RAISE_SECONDS + WAVE_SECONDS + LOWER_SECONDS

# Absolute model angles, radians. The elbow's zero pose is already bent;
# adding 1.55 radians straightens the arm and makes this look like a reach.
# Illustrative kinematic simulation only, not physical robot commands.
wave_targets = {
    "right_shoulder_pitch_joint": -0.30,
    "right_shoulder_roll_joint": -1.40,
    "right_shoulder_yaw_joint": -1.50,
    "right_elbow_joint": 0.10,
    "right_wrist_roll_joint": 0.0,
}


def animate_wave(elapsed):
    data.qpos[:] = initial_pose
    elapsed -= REST_SECONDS
    if elapsed < RAISE_SECONDS:
        strength = smoothstep(elapsed / RAISE_SECONDS)
    elif elapsed < RAISE_SECONDS + WAVE_SECONDS:
        strength = 1.0
    else:
        strength = 1.0 - smoothstep(
            (elapsed - RAISE_SECONDS - WAVE_SECONDS) / LOWER_SECONDS
        )

    # Three gentle side-to-side sweeps, fading in and out without a snap.
    phase = (elapsed - RAISE_SECONDS) / WAVE_SECONDS
    sway = 0.0
    if 0.0 < phase < 1.0:
        envelope = math.sin(math.pi * phase) ** 2
        sway = 0.30 * envelope * math.sin(6.0 * math.pi * phase)

    for name, target in wave_targets.items():
        base = initial_pose[joints[name]["address"]]
        angle = base + (target - base) * strength
        if name == "right_shoulder_yaw_joint":
            angle += sway
        set_joint(name, angle)

    mujoco.mj_forward(model, data)


gesture_requested = threading.Event()
running = threading.Event()
running.set()


def keyboard_listener():
    while running.is_set():
        try:
            command = input().strip().lower()
        except EOFError:
            break

        if command in ("w", "wave"):
            gesture_requested.set()

        elif command in ("q", "quit"):
            running.clear()
            break


def main():
    threading.Thread(
        target=keyboard_listener,
        daemon=True
    ).start()

    print("\nG1 Gesture Simulator")
    print("Starting with both arms resting down.")
    print("Press W + Enter: rest, raise, wave, lower")
    print("Press Q + Enter to quit\n")

    with mujoco.viewer.launch_passive(model, data) as viewer:
        viewer.cam.lookat[:] = [0.0, 0.0, 0.9]
        viewer.cam.distance = 2.3
        viewer.cam.azimuth = 15
        viewer.cam.elevation = -10
        wave_start = None

        while viewer.is_running() and running.is_set():

            if gesture_requested.is_set():
                gesture_requested.clear()
                if wave_start is None:
                    wave_start = time.monotonic()
                    print("G1: Resting down, then raising arm to wave...")

            if wave_start is not None:
                elapsed = time.monotonic() - wave_start

                if elapsed <= GESTURE_SECONDS:
                    animate_wave(elapsed)
                else:
                    data.qpos[:] = initial_pose
                    mujoco.mj_forward(model, data)
                    wave_start = None
                    print("Gesture completed")

            viewer.sync()
            time.sleep(0.02)

    running.clear()
    print("Simulator closed")



if __name__ == "__main__":
    main()
