# G1 Smart AI

Voice commands, gesture simulation, object detection, and an optional physical Unitree G1 connection.

## Start here

```bash
cd /Users/nishan/G1-Smart-AI
python3 launch.py voice-sim
```

Say “G one, wave hello”, “help”, or “walk”. Typed commands also work. Use `--no-voice` for keyboard only, or `--list` to list commands without opening the viewer.

## Apps

| Command | Purpose |
| --- | --- |
| `python3 launch.py voice-sim` | Voice/typed gestures and visual walking simulation |
| `python3 launch.py wave` | Keyboard wave starting with arms resting down |
| `python3 launch.py static` | Stationary G1 model viewer |
| `python3 launch.py physics` | Physics stepping experiment; no standing controller |
| `python3 launch.py voice` | Standalone offline speech recognition; prints commands |
| `python3 launch.py vision` | Mac camera object detection |
| `python3 launch.py control` | Control bridge, defaulting to simulation |
| `python3 launch.py hardware --interface en5` | Read-only hardware connection/action discovery |
| `python3 launch.py state --interface en5` | Original read-only DDS state monitor |
| `python3 launch.py test` | Hardware bridge tests using mock clients |

Replace `en5` with the actual robot-facing interface. Physical action requests require `--arm`; walking requires a further `--enable-walking`. See [hardware instructions](docs/hardware_voice_control.md). Simulation poses are illustrations, not validated physical trajectories.

## Folder layout

```text
apps/
  simulation/   voice_gesture_simulator.py, wave_gesture.py,
                static_viewer.py, physics_simulator.py
  hardware/     voice_robot_control.py, state_monitor.py
  voice/        offline_command_recognizer.py
  vision/       object_detection.py
models/
  speech/       Vosk English recognition model
  vision/       YOLO11n weights
tests/         mock-client tests; viewer/ contains manual viewer checks
docs/          hardware guide and original-to-new file mapping
logs/          installation logs
archive/
  prototypes/       older gesture experiments
  backups/          earlier saved script versions
  pre_organization/ exact source snapshots before this reorganization
  downloads/        original Vosk ZIP
  unused/           original empty voice_recognition directory
  cache/            original Python cache
launch.py       common launcher
```

The `.venv` environment serves vision; `.venv-g1` serves speech, MuJoCo, and SDK work. The existing `unitree_sdk2_python`, `unitree_mujoco`, and `cyclonedds` repositories stay at the project root to preserve installed SDK references and native build paths. They are third-party dependencies, not the application source.

Active scripts resolve assets from the project folder, so they also run by absolute path from another working directory. Archived scripts retain historical behavior, with asset paths repaired for the current layout. Unmodified source copies are preserved in `archive/before_path_repairs.zip`. [File mapping](docs/organization_manifest.json) records every move. No project source or model files were deleted.

## Readiness checks

Every app launch automatically runs the relevant checks first. A failure blocks the launch. Listing commands and running automated tests do not access the microphone or robot.

To check without launching:

```bash
python3 launch.py check
python3 launch.py check --target hardware --interface en5
python3 launch.py check --target hardware --interface en5 --arm
python3 launch.py check --target hardware --interface en5 --arm --enable-walking
python3 launch.py check --target vision
```

`PASS` confirms a check succeeded, `FAIL` blocks launch, and `SKIP` means the check is not applicable or depends on a failed prerequisite. Add `--no-voice` to check/run without microphone input. Hardware checks receive state and query services only; even `check ... --arm` does not send motion. It additionally checks the microphone and that arm release is available. Replace `en5` with your robot-facing interface.

Simulation does not require robot connectivity. Hardware requires a live DDS state stream and action discovery; camera access is checked only for vision. Graphics checks render a test frame; they do not operate the viewer window. A working microphone stream does not establish speech-recognition accuracy. Checks never install packages or change network settings automatically.

## Adding vision, movements, or speech output

Follow [the feature and folder guide](docs/project_structure.md). Future movement definitions belong in `motions/simulation/` or `motions/hardware/`; audio clips belong in `assets/audio/`. Vosk handles speech input. The simulator speaks through the Mac using local text-to-speech. Physical robot speech uses the separate Unitree audio service and is not yet integrated.

## Try speech without a robot

```bash
python3 launch.py speak --text "Hello! I am G one. Welcome!"
python3 launch.py voice-sim
```

In the simulator say or type `say hello`, `introduce yourself`, `say welcome`, or `say goodbye`. `wave hello` remains a gesture. Speech plays through the Mac speakers, with a caption in the viewer; it is not emitted by the simulated 3D model. The recognizer pauses during speech and briefly afterward to reduce speaker feedback. Typed `stop` interrupts speech. Use `--mute` to turn off speech output, or `--no-voice` for typed input while keeping speech output enabled. Local speech uses macOS's existing `say` engine and needs no additional downloaded model. It does not require a language model or internet connection.

## Speak and wave together

```bash
python3 launch.py greeting
```

Say or type `hello`, `introduce yourself`, or `wave hello`. The robot starts raising its arm when local speech is requested; both run concurrently. `stop` interrupts speech and lowers the arm. Speech input pauses while the Mac is speaking, so use typed `stop` during speech.

Use `--demo` for an automatic greeting after opening, `--no-voice` for typed commands, or `--text "Hello! Welcome to our event."` to customize the introduction. The default text is `INTRODUCTION` in `apps/simulation/greeting_with_wave.py`. This is a separate demo; existing voice-sim behavior is unchanged. Speech synthesis startup can introduce a small audible delay; this is concurrent playback, not word-to-motion synchronization.

## Generated conversation with Ollama Cloud

Use `python3 launch.py conversation` for voice-only generated replies, or add `--no-voice` for typed questions. An Ollama account/API key and model access are required. See [API key setup and conversation instructions](docs/ollama_cloud_conversation.md). App: `apps/voice/ollama_conversation.py`; cloud client: `apps/ai/ollama_cloud_client.py`.

## Launching from a different folder

Use the project launcher by absolute path from anywhere:

```bash
python3 /Users/nishan/G1-Smart-AI/launch.py wave
```

From `archive/`, `python3 launch.py wave` also works through its forwarding launcher. The old `mjpython g1_gestures.py` command only works when that actual filename exists in the current folder; use `wave` for the latest corrected gesture.
