"""Project entry point. Run python3 launch.py --help for available apps."""
import argparse
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
APPS = {
    'conversation': ('.venv-g1/bin/python', 'apps/voice/ollama_conversation.py'),
    'greeting': ('.venv-g1/bin/mjpython', 'apps/simulation/greeting_with_wave.py'),
    'voice-sim': ('.venv-g1/bin/mjpython', 'apps/simulation/voice_gesture_simulator.py'),
    'wave': ('.venv-g1/bin/mjpython', 'apps/simulation/wave_gesture.py'),
    'physics': ('.venv-g1/bin/mjpython', 'apps/simulation/physics_simulator.py'),
    'static': ('.venv-g1/bin/mjpython', 'apps/simulation/static_viewer.py'),
    'control': ('.venv-g1/bin/python', 'apps/hardware/voice_robot_control.py'),
    'hardware': ('.venv-g1/bin/python', 'apps/hardware/voice_robot_control.py'),
    'state': ('.venv-g1/bin/python', 'apps/hardware/state_monitor.py'),
    'speak': ('.venv-g1/bin/python', 'apps/voice/local_speech.py'),
    'voice': ('.venv-g1/bin/python', 'apps/voice/offline_command_recognizer.py'),
    'vision': ('.venv/bin/python', 'apps/vision/object_detection.py'),
}


def main():
    parser = argparse.ArgumentParser(description=__doc__, add_help=False)
    parser.add_argument('app', choices=(*APPS, 'test', 'check'))
    if len(sys.argv) == 1 or sys.argv[1] in ('-h', '--help'):
        parser.print_help()
        return 0
    args, extra = parser.parse_known_args()
    if args.app == 'check':
        from preflight import main as check_main
        sys.argv = [str(ROOT / 'preflight.py'), *extra]
        return check_main()
    if args.app != 'test' and not any(flag in extra for flag in ('--help', '-h', '--list', '--devices', '--models', '--check')):
        from preflight import run_checks
        if not run_checks(args.app, extra):
            return 1
    if args.app == 'test':
        command = [str(ROOT / '.venv-g1/bin/python'), '-m', 'unittest',
                   'discover', '-s', str(ROOT / 'tests'), '-p', 'test_*.py', *extra]
    else:
        runtime, script = APPS[args.app]
        # Listing commands does not require the macOS graphics runtime.
        if args.app in ('voice-sim', 'greeting') and '--list' in extra:
            runtime = '.venv-g1/bin/python'
        command = [str(ROOT / runtime), str(ROOT / script)]
        if args.app == 'hardware':
            command.append('--hardware')
        command += extra
    try:
        return subprocess.call(command, cwd=ROOT)
    except KeyboardInterrupt:
        return 130


if __name__ == '__main__':
    raise SystemExit(main())
