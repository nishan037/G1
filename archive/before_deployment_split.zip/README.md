# G1 Smart AI

Two main applications:

| File | Purpose |
| --- | --- |
| `apps/g1_control.py` | Voice/text basic commands, simulation, speech + wave greeting, and explicit physical G1 mode |
| `apps/g1_conversation.py` | Ollama Cloud conversation with typed/voice input and generated spoken replies |

## Basic control: start here

```bash
cd /Users/nishan/G1-Smart-AI
python3 launch.py control
```

Say or type commands in the terminal: `wave`, `clap`, `shake hands`, `hands up`, `high five`, `hug`, `heart`, `walk`, `walk backward`, `turn left`, `turn right`, `stop`, `help`, `quit`. All aliases are listed with `python3 launch.py control --list`.

`greet` or `hello and wave` speaks the introduction while raising the arm to wave. `say hello`, `introduce yourself`, `say welcome`, and `say goodbye` speak only. `wave hello` waves only. Your existing customized introduction is retained in `SPEECH_RESPONSES` inside `apps/g1_control.py`.

Use `--no-voice` for typed commands, `--mute` to disable Mac speech, `--device INDEX` to select a microphone, `--demo` to cycle the simulation, or `--text "Hello! Welcome."` to customize the combined greeting. Input transcription pauses while the Mac speaks; typed `stop` always remains available.

Simulation uses the G1 23-DOF model. Gestures and walking are illustrative kinematic animations, not validated physical trajectories. The physics-only experiment, static viewer, and standalone wave demos have been superseded by this one control app.

## Physical robot

```bash
python3 launch.py hardware --interface en5
python3 launch.py hardware --interface en5 --arm
```

Replace `en5` with the robot-facing interface. The first command is read-only discovery. The second explicitly enables supported onboard arm actions. Walking additionally requires `--enable-walking` and uses bounded one-second requests. Physical compatibility and movement remain untested on your robot. See [hardware guide](docs/hardware_voice_control.md).

The basic-control file imports MuJoCo only when simulation starts; hardware command parsing no longer depends on the simulator. Mac speech is still local output, including when controlling hardware; robot speaker output is not yet integrated. On a system without macOS `say`, use `--mute` for basic hardware control until a robot/local speaker backend is installed.

## Ollama conversation

```bash
python3 launch.py conversation --check
python3 launch.py conversation
```

The cloud client and conversation loop are in one file, `apps/g1_conversation.py`. It reuses `LocalSpeaker` from `g1_control.py`, without loading a simulator or opening SDK channels. Your saved API configuration is retained. You can override it with `OLLAMA_API_KEY` in the environment. See [cloud instructions](docs/ollama_cloud_conversation.md). No LLM response is executed as a movement command.

## Preflight and tests

```bash
python3 launch.py check --target control
python3 launch.py check --target hardware --interface en5
python3 launch.py check --target conversation
python3 launch.py test
```

App launches run the relevant checks automatically and stop on failure. `--help`, command listing, model listing, and tests do not trigger unrelated microphone or robot checks. Cloud connection checks use a small test request. Preflight success confirms current access, not physical clearance or safe motion.

## Other files

- `apps/vision/object_detection.py`: separate camera detection app; run `python3 launch.py vision`.
- `models/`: speech and vision assets.
- `motions/`: documented locations for future movement definitions.
- `assets/audio/`: future audio clips.
- `tests/`, `docs/`, `logs/`: verification, guides, and logs.
- `archive/gesture_consolidation_backup.zip`: all superseded app/gesture sources and prior docs/tests. The saved cloud configuration is included; keep this backup private.
- `.venv`, `.venv-g1`, `unitree_sdk2_python`, `unitree_mujoco`, `cyclonedds`: environments and third-party dependencies kept in place.

Older commands such as `launch.py wave`, `voice-sim`, and `greeting` are replaced by `launch.py control`. From any directory use `python3 /Users/nishan/G1-Smart-AI/launch.py control`. From `archive/`, its forwarding `launch.py` works with the same new commands.
