# Physical G1 voice/text control

All basic command handling, voice recognition, simulated gesture definitions, and G1 SDK routing are now in `apps/g1_control.py`. Simulation is the default and does not initialize SDK channels.

## Connection first

Connect the PC to the robot network according to the exact robot configuration. Identify the robot-facing interface; `en5` is only an example. On macOS, `networksetup -listallhardwareports` helps identify adapters.

```bash
python3 launch.py hardware --interface en5
```

Preflight and startup receive `rt/lowstate` on DDS domain 0 and call `GetActionList()`. No motion requests are sent without `--arm`. The state stream must stay fresh, and action names/IDs must match the installed SDK. Robot Standard versus EDU, firmware, enabled interfaces, and developer access determine compatibility; an external computer does not bypass restrictions.

## Commands

```bash
python3 launch.py hardware --interface en5 --arm
```

Say or type `help` to list discovered presets. Generic `wave` maps to a discovered high wave or face wave. `greet` starts an onboard wave and the customized introduction on the Mac speaker. `say hello` and other speech commands also play locally. Physical robot speaker output is not yet integrated.

Simulation-only left/both waves are refused unless an exact supported preset exists; simulated joint angles are never sent to the physical robot. The app does not change operating mode, stand the robot up, or disable torque. Use Unitree's normal controls to put the robot in its appropriate standing mode before testing an action in clear space. Keep the robot remote stop available: voice stop can be missed, and a network stop request cannot guarantee delivery after disconnection.

Walking requires an additional explicit opt-in, after verifying the robot's locomotion service and mode:

```bash
python3 launch.py hardware --interface en5 --arm --enable-walking
```

Commands are `walk`, `walk backward`, `turn left`, and `turn right`, using one-second bursts at requested 0.10 m/s translation or 0.15 rad/s rotation. Refresh requests expire after a requested 0.4 seconds. `stop` requests zero velocity and releases an active arm pose. A stale state stream or RPC failure stops refreshes, attempts a stop, and locks further commands until restart. These timing semantics still require validation on actual firmware.

Busy commands are refused rather than saved for later movement. Accepted arm actions are released after three seconds; SDK success means the request was accepted, not that motion completed. Some onboard trajectories may last longer or release differently. `quit` and Ctrl+C attempt to stop tracked actions. No autonomous navigation, obstacle avoidance, fall detector, or independent emergency stop is implemented.

Use `--no-voice`, `--mute`, and `--device INDEX` as needed. A Raspberry Pi/Linux host requires compatible SDK/audio dependencies; `--mute` bypasses the macOS-only local speech output. The virtual environments bundled here are Mac environments and must be rebuilt for another operating system.

Tests use mock SDK clients. Physical network access, audio, and robot motion have not yet been validated.
