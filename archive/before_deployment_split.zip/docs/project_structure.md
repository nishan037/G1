# Current project structure

`apps/g1_control.py` is the single basic-command app: voice/text interpretation, local speech, kinematic simulation, combined greeting, discovered SDK actions, and bounded optional physical locomotion.

`apps/g1_conversation.py` is the Ollama voice app: cloud client, generalized speech input, short conversation memory, and generated replies. It imports the local speaker from the control file but does not initialize MuJoCo or SDK communication.

Vision remains independent in `apps/vision/`. Put future reusable motion definitions in `motions/simulation/` and verified onboard mappings in `motions/hardware/`. Store recognition/detection models in `models/` and audio clips in `assets/audio/`. Tests and deployment instructions belong in `tests/` and `docs/`.

Add commands to `ALIASES` in the control app, simulation trajectories to `Gestures`, and physical mappings only for verified supported onboard actions. Do not turn a simulated pose into a physical motor command. Vosk recognizes speech; local speech uses macOS `say`; future physical speaker output belongs in a backend within `g1_control.py`, using the G1 audio service after checking compatibility.

Superseded scripts were removed after preserving them and prior docs/tests in `archive/gesture_consolidation_backup.zip`. The backup includes saved API configuration and must remain private. Third-party repositories and environments remain at their existing paths.
