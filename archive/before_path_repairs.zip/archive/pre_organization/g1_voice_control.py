"""Voice control bridge: simulation by default, explicit opt-in for physical G1.

python g1_voice_control.py                              # existing MuJoCo simulation
python g1_voice_control.py --hardware --interface enX   # read-only connection probe
python g1_voice_control.py --hardware --interface enX --arm  # arm gestures
Add --enable-walking only after separately verifying the robot locomotion service.
No SDK channels are opened in simulation mode. No motion is sent by a probe.
"""
import argparse
import json
from pathlib import Path
import queue
import re
import socket
import subprocess
import sys
import threading
import time

ROOT = Path(__file__).resolve().parent


def load_voice():
    import importlib.util
    spec = importlib.util.spec_from_file_location('g1_voice_gestures', ROOT / 'gestures_with_voice.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def normalized(name):
    return ' '.join(re.sub(r'[^a-z0-9]+', ' ', str(name).lower()).split())


def discover_actions(payload, known):
    """Accept common discovery layouts; only accept matching known name/ID pairs.

    Custom teach actions are intentionally not enabled. Unknown payloads fail closed.
    """
    result = {}
    names = {normalized(k): k for k in known}

    def add(name, ident):
        key = names.get(normalized(name))
        if isinstance(ident, str) and ident.isdigit():
            ident = int(ident)
        if key and type(ident) is int and known[key] == ident:
            result[key] = ident

    def visit(value):
        if isinstance(value, str):
            try:
                visit(json.loads(value))
            except (ValueError, TypeError):
                pass
        elif isinstance(value, list):
            for child in value:
                visit(child)
        elif isinstance(value, dict):
            add(value.get('name', value.get('action_name', '')),
                value.get('id', value.get('action_id')))
            for key, child in value.items():
                add(key, child)
                if isinstance(child, (dict, list)) or key in ('data', 'actions', 'action_list'):
                    visit(child)
    visit(payload)
    return result


class TimedCommands:
    def __init__(self):
        self.q = queue.Queue(maxsize=16)

    def put(self, action):
        try:
            self.q.put_nowait((time.monotonic(), action))
        except queue.Full:
            print('Command buffer full; command ignored.', flush=True)


class Hardware:
    def __init__(self, arm, loco, actions, last_state, enable_walking=False):
        self.arm_client = arm
        self.loco = loco
        self.actions = actions
        self.last_state = last_state
        self.enable_walking = enable_walking
        self.fault = False
        self.moving_until = 0.
        self.arm_until = 0.
        self.next_send = 0.
        self.velocity = (0., 0., 0.)
        self.state_timeout = 1.0

    def healthy(self, now):
        return now - self.last_state() <= self.state_timeout

    def checked(self, label, fn):
        try:
            code = fn()
            if code != 0:
                raise RuntimeError(f'return code {code}')
            return True
        except Exception as exc:
            print(f'{label} failed: {exc}', flush=True)
            self.fault = True
            return False

    def stop(self):
        # Best effort only: network failure can prevent receipt. Never disable torque.
        was_moving = self.moving_until > 0
        had_arm = self.arm_until > 0
        self.moving_until = self.arm_until = 0.
        if was_moving:
            self.checked('Stop walking', lambda: self.loco.SetVelocity(0., 0., 0., .4))
        if had_arm and 'release arm' in self.actions:
            self.checked('Release arm', lambda: self.arm_client.ExecuteAction(self.actions['release arm']))

    def tick(self, now):
        if not self.healthy(now) and not self.fault:
            print('Robot state is stale. Stopping; restart to reconnect.', flush=True)
            self.fault = True
            self.stop()
        if self.fault:
            return
        if self.moving_until:
            if now >= self.moving_until:
                self.stop()
            elif now >= self.next_send:
                # Each request expires onboard; do not request continuous movement.
                if not self.checked('Walking', lambda: self.loco.SetVelocity(*self.velocity, .4)):
                    self.stop()
                self.next_send = now + .15
        if self.arm_until and now >= self.arm_until:
            self.stop()

    def command(self, action, now):
        if action in ('stop', 'release arm'):
            # Explicit stop also sends a stop request when no local action is tracked.
            self.moving_until = max(self.moving_until, now) if self.enable_walking else 0.
            self.arm_until = max(self.arm_until, now)
            self.stop()
            return
        if self.fault or not self.healthy(now):
            print('Connection not healthy; motion refused.', flush=True)
            return
        if self.moving_until or self.arm_until:
            print('Busy: wait or say stop. This command was not queued.', flush=True)
            return
        if action in ('walk', 'walk backward', 'turn left', 'turn right'):
            if not self.enable_walking:
                print('Walking disabled. Restart with --enable-walking after verifying locomotion.', flush=True)
                return
            self.velocity = {
                'walk': (.10, 0., 0.), 'walk backward': (-.10, 0., 0.),
                'turn left': (0., 0., .15), 'turn right': (0., 0., -.15),
            }[action]
            self.moving_until = now + 1.0
            self.next_send = now
            self.tick(now)
            return
        # Generic wave selects an onboard wave. Never upload simulated joint angles.
        target = ('high wave' if 'high wave' in self.actions else 'face wave') if action == 'wave' else action
        if target not in self.actions:
            print(f'Action unavailable on this robot: {action}', flush=True)
            return
        self.arm_until = now + 3.0
        if not self.checked(target, lambda: self.arm_client.ExecuteAction(self.actions[target])):
            self.stop()
        else:
            print(f'Robot accepted {target}; arm release scheduled in 3 seconds.', flush=True)


def connect(interface, enable_walking):
    available = {name for _, name in socket.if_nameindex()}
    if interface not in available or interface in ('lo', 'lo0'):
        raise RuntimeError(f'Choose a robot-facing interface from: {sorted(available - {"lo", "lo0"})}')
    sys.path.insert(0, str(ROOT / 'unitree_sdk2_python'))
    from unitree_sdk2py.core.channel import ChannelFactoryInitialize, ChannelSubscriber
    from unitree_sdk2py.idl.unitree_hg.msg.dds_ import LowState_
    from unitree_sdk2py.g1.arm.g1_arm_action_client import G1ArmActionClient, action_map
    from unitree_sdk2py.g1.loco.g1_loco_client import LocoClient
    ChannelFactoryInitialize(0, interface)
    last = [0.]
    received = threading.Event()

    def on_state(msg):
        if len(msg.motor_state) >= 23:
            last[0] = time.monotonic()
            received.set()

    subscriber = ChannelSubscriber('rt/lowstate', LowState_)
    subscriber.Init(on_state, 10)
    try:
        if not received.wait(5):
            raise RuntimeError('No G1 rt/lowstate received in 5 seconds. Check robot/network/interface.')
        arm = G1ArmActionClient()
        arm.SetTimeout(3.)
        arm.Init()
        code, payload = arm.GetActionList()
        if code != 0:
            raise RuntimeError(f'Arm action discovery failed: {code}. Firmware/service support must be checked.')
        print('Robot action-list response:\n' + json.dumps(payload, indent=2), flush=True)
        actions = discover_actions(payload, action_map)
        print('Matched supported presets: ' + ', '.join(sorted(actions)), flush=True)
        loco = None
        if enable_walking:
            loco = LocoClient()
            loco.SetTimeout(.3)
            loco.Init()
            code, fsm = loco.GetFsmId()
            if code != 0:
                raise RuntimeError(f'Locomotion state query failed: {code}')
            print(f'Locomotion FSM: {fsm}. This program does not change the robot operating mode.', flush=True)
        arm.SetTimeout(.3)
        return Hardware(arm, loco, actions, lambda: last[0], enable_walking), subscriber
    except Exception:
        subscriber.Close()
        raise


def hardware_help(controller):
    print('HARDWARE commands: ' + ', '.join(sorted(controller.actions)), flush=True)
    print('Also: wave hello, stop, arms down, help, quit. '
          + ('Walking: walk / walk backward / turn left / turn right (1-second bursts).'
             if controller.enable_walking else 'Walking is disabled.'), flush=True)
    print('Left/both wave simulations have no automatic physical mapping. '
          'Voice stop is not an emergency stop; keep the robot remote available.', flush=True)


def run_hardware(args):
    controller, subscriber = connect(args.interface, args.enable_walking)
    if not args.arm or args.list:
        subscriber.Close()
        print('Read-only probe complete. No motion commands sent. Use --arm to enable gestures.')
        return
    if 'release arm' not in controller.actions:
        subscriber.Close()
        raise RuntimeError('Release-arm action was not discovered; refusing to enable gestures.')
    if not controller.healthy(time.monotonic()):
        subscriber.Close()
        raise RuntimeError('State stream became stale during discovery; no motion enabled.')
    voice = load_voice()
    done = threading.Event()
    commands = TimedCommands()

    def keyboard():
        while not done.is_set():
            try:
                text = input()
            except EOFError:
                commands.put('quit')
                return
            action = voice.interpret_command(text)
            if action:
                commands.put(action)
            else:
                print('Unknown command; type help.', flush=True)

    hardware_help(controller)
    print('HARDWARE CONTROL ENABLED. Start with one stationary gesture in clear space.', flush=True)
    threading.Thread(target=keyboard, daemon=True).start()
    if not args.no_voice:
        device = int(args.device) if args.device and args.device.isdigit() else args.device
        threading.Thread(target=voice.voice_worker, args=(commands, done, device), daemon=True).start()
    try:
        while not done.is_set():
            now = time.monotonic()
            controller.tick(now)
            if controller.fault:
                break
            try:
                timestamp, action = commands.q.get(timeout=.05)
            except queue.Empty:
                continue
            if action == 'quit':
                break
            if action == 'help':
                hardware_help(controller)
            elif now - timestamp <= 1.0 or action in ('stop', 'release arm'):
                controller.command(action, time.monotonic())
            else:
                print('Stale command ignored.', flush=True)
    finally:
        done.set()
        controller.stop()
        subscriber.Close()


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--hardware', action='store_true')
    parser.add_argument('--interface', help='network interface connected to robot; e.g. en5 or eth0')
    parser.add_argument('--arm', action='store_true', help='explicitly enable physical action requests')
    parser.add_argument('--enable-walking', action='store_true', help='opt in to bounded physical locomotion requests')
    parser.add_argument('--no-voice', action='store_true')
    parser.add_argument('--device')
    parser.add_argument('--list', action='store_true')
    args = parser.parse_args()
    if not args.hardware:
        if args.arm or args.enable_walking or args.interface:
            parser.error('Hardware options require --hardware.')
        runner = sys.executable if args.list else str(ROOT / '.venv-g1/bin/mjpython')
        command = [runner, str(ROOT / 'gestures_with_voice.py')]
        if args.no_voice:
            command.append('--no-voice')
        if args.list:
            command.append('--list')
        if args.device:
            command += ['--device', args.device]
        return subprocess.call(command)
    if not args.interface:
        parser.error('--hardware requires --interface; the default hardware run is read-only.')
    if args.enable_walking and not args.arm:
        parser.error('--enable-walking requires --arm.')
    try:
        run_hardware(args)
    except KeyboardInterrupt:
        print('Stopped.')
    except Exception as exc:
        print(f'Hardware control unavailable: {exc}', file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
